//
//  UIViewX.swift
//  DesignableX
//
//  Created by Mark Moeykens on 12/31/16.
//  Copyright © 2016 Mark Moeykens. All rights reserved.
//

import UIKit

@IBDesignable
class UIViewX: UIView {
	
	// MARK: - Border
	
	@IBInspectable public var borderColor: UIColor = UIColor.clear {
		didSet {
			layer.borderColor = borderColor.cgColor
		}
	}
	
	@IBInspectable public var borderWidth: CGFloat = 0 {
		didSet {
			layer.borderWidth = borderWidth
		}
	}
	
	@IBInspectable public var cornerRadius: CGFloat = 0 {
		didSet {
			layer.cornerRadius = cornerRadius
		}
	}
	
	// MARK: - Shadow
	
	@IBInspectable public var shadowOpacity: CGFloat = 0 {
		didSet {
			layer.shadowOpacity = Float(shadowOpacity)
		}
	}
	
	@IBInspectable public var shadowColor: UIColor = UIColor.clear {
		didSet {
			layer.shadowColor = shadowColor.cgColor
		}
	}
	
	@IBInspectable public var shadowRadius: CGFloat = 0 {
		didSet {
			layer.shadowRadius = shadowRadius
		}
	}
	
	@IBInspectable public var shadowOffsetY: CGFloat = 0 {
		didSet {
			layer.shadowOffset.height = shadowOffsetY
		}
	}
}

@IBDesignable
class UIImageViewX: UIImageView {
    
    // MARK: - Border
    
    @IBInspectable public var borderColor: UIColor = UIColor.clear {
        didSet {
            layer.borderColor = borderColor.cgColor
        }
    }
    
    @IBInspectable public var borderWidth: CGFloat = 0 {
        didSet {
            layer.borderWidth = borderWidth
        }
    }
    
    @IBInspectable public var cornerRadius: CGFloat = 0 {
        didSet {
            layer.cornerRadius = cornerRadius
        }
    }
    
    override func draw(_ rect: CGRect) {
        if clipsToBounds {
            layer.masksToBounds = true
            layer.cornerRadius = cornerRadius
        }
    }
}

@IBDesignable
class UIButtonX: UIButton {
    
    // MARK: - Border
    
    @IBInspectable public var borderColor: UIColor = UIColor.clear {
        didSet {
            layer.borderColor = borderColor.cgColor
        }
    }
    
    @IBInspectable public var borderWidth: CGFloat = 0 {
        didSet {
            layer.borderWidth = borderWidth
        }
    }
    
    @IBInspectable public var cornerRadius: CGFloat = 0 {
        didSet {
            layer.cornerRadius = cornerRadius
        }
    }
}

@IBDesignable
class UIVisualEffectViewX: UIVisualEffectView {
    
    // MARK: - Border
    
    @IBInspectable public var borderColor: UIColor = UIColor.clear {
        didSet {
            layer.borderColor = borderColor.cgColor
        }
    }
    
    @IBInspectable public var borderWidth: CGFloat = 0 {
        didSet {
            layer.borderWidth = borderWidth
        }
    }
    
    @IBInspectable public var cornerRadius: CGFloat = 0 {
        didSet {
            layer.cornerRadius = cornerRadius
        }
    }
}
